Converted versions of cmudict; suitable as input to trainer and decoder
-----------------------------------------------------------------------
[20080219] (air)
[20100118] (air)  updated; reflects new organization

This is the Sphinx-compatible version of the dictionary, compiled from
the corresponding version of cmudict. For human browsing, please use
the uncompiled version.

To produce a new version of the Sphinx dictionary see instructions in
../scripts/README. You should NOT be compiling the dictionary if you
are not a maintainer: This folder already contains up to date compiled
version of the Sphinx dictionary.

Note that compilation produces two (identical) files. The generic
cmudict_SPHINX_40 is for convenience: the name is not expected to
change as the dictionary evolves. It is (reasonably) safe to use it in
your programs and scripts.

